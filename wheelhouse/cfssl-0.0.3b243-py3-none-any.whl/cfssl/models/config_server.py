# -*- coding: utf-8 -*-
# Copyright 2016 LasLabs Inc.
# License MIT (https://opensource.org/licenses/MIT).

from .config_mixer import ConfigMixer


class ConfigServer(ConfigMixer):
    """ It provides a Server Config compatible with CFSSL. """
